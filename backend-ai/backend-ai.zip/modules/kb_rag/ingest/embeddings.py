import os
import logging
import threading
from typing import Dict, List

logger = logging.getLogger(__name__)

_embedder_instances: Dict[str, object] = {}
_embedder_lock = threading.RLock()

def get_embedder(model_name: str | None = None):
    """按模型名缓存 HuggingFace Embedding 模型，默认值保持向后兼容。"""
    resolved_model = model_name or os.getenv("EMBEDDING_MODEL", "BAAI/bge-small-zh-v1.5")
    if resolved_model in _embedder_instances:
        return _embedder_instances[resolved_model]

    with _embedder_lock:
        if resolved_model in _embedder_instances:
            return _embedder_instances[resolved_model]
        try:
            from sentence_transformers import SentenceTransformer
            logger.info(f"Loading Embedding model: {resolved_model}")
            embedder = SentenceTransformer(resolved_model)
            _embedder_instances[resolved_model] = embedder
            logger.info(f"Embedding model loaded successfully: {resolved_model}")
            return embedder
        except Exception as e:
            logger.error(f"Failed to load Embedding model '{resolved_model}': {e}", exc_info=True)
            raise

def generate_embeddings(
    texts: List[str],
    batch_size: int = 32,
    model_name: str | None = None,
) -> List[List[float]]:
    """
    生成向量

    Args:
        texts: 文本列表
        batch_size: 批处理大小，控制每批发送的文本数量，避免大文档集内存溢出
        model_name: 可选模型名；未提供时读取 EMBEDDING_MODEL
    """
    embedder = get_embedder(model_name)
    return embedder.encode(texts, batch_size=batch_size, normalize_embeddings=True).tolist()
