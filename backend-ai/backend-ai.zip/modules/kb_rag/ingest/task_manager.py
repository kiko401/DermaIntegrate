﻿import os
import httpx
import logging
import asyncio
from shared.config import (
    CALLBACK_CONNECT_TIMEOUT, CALLBACK_READ_TIMEOUT,
    CALLBACK_WRITE_TIMEOUT, CALLBACK_POOL_TIMEOUT,
)
from ..schemas import IngestCallback

logger = logging.getLogger(__name__)

CALLBACK_TIMEOUT = httpx.Timeout(
    connect=CALLBACK_CONNECT_TIMEOUT,
    read=CALLBACK_READ_TIMEOUT,
    write=CALLBACK_WRITE_TIMEOUT,
    pool=CALLBACK_POOL_TIMEOUT,
)
MAX_CALLBACK_RETRIES = 3
CALLBACK_RETRY_DELAY = 1.0


def _get_callback_target(task_id: int):
    base_url = os.getenv("APP_BASE_URL")
    secret = os.getenv("X_INTERNAL_SECRET")
    if not base_url or not secret:
        return None, None
    callback_url = f"{base_url}/api/rag/tasks/{task_id}/callback"
    headers = {
        "X-Internal-Token": secret,
        "Content-Type": "application/json",
    }
    return callback_url, headers


async def _post_callback(callback_url: str, headers: dict, payload: IngestCallback, *, strict: bool, label: str):
    last_error = None
    for attempt in range(1, MAX_CALLBACK_RETRIES + 1):
        try:
            async with httpx.AsyncClient(timeout=CALLBACK_TIMEOUT) as client:
                response = await client.post(callback_url, json=payload.model_dump(), headers=headers)
                if response.status_code == 200:
                    logger.info(f"{label} callback succeeded (attempt {attempt})")
                    return True
                last_error = f"HTTP {response.status_code} - {response.text}"
                logger.warning(f"{label} callback failed (attempt {attempt}): {last_error}")
        except httpx.TimeoutException:
            last_error = f"timeout after {CALLBACK_TIMEOUT.connect}s connect + {CALLBACK_TIMEOUT.read}s read"
            logger.warning(f"{label} callback timed out (attempt {attempt}): {last_error}")
        except Exception as e:
            last_error = str(e)
            logger.warning(f"{label} callback exception (attempt {attempt}): {last_error}")

        if attempt < MAX_CALLBACK_RETRIES:
            await asyncio.sleep(CALLBACK_RETRY_DELAY)

    if strict:
        logger.error(f"{label} callback exhausted all {MAX_CALLBACK_RETRIES} retries. Last error: {last_error}")
        raise RuntimeError(f"{label} callback failed after {MAX_CALLBACK_RETRIES} retries: {last_error}")

    logger.warning(f"{label} progress callback gave up after {MAX_CALLBACK_RETRIES} retries: {last_error}")
    return False


async def send_task_progress(
    task_id: int,
    task_code: str,
    stage: str,
    progress: int,
    message: str | None = None,
):
    """Best-effort progress callback; failure should not break ingest."""
    callback_url, headers = _get_callback_target(task_id)
    if not callback_url or not headers:
        logger.warning("APP_BASE_URL or X_INTERNAL_SECRET is not configured. Progress callback skipped.")
        return False

    payload = IngestCallback(
        task_code=task_code,
        status="running",
        stage=stage,
        progress=progress,
        message=message,
    )
    return await _post_callback(callback_url, headers, payload, strict=False, label=f"task {task_id}")


async def send_task_callback(
    task_id: int,
    task_code: str,
    chunk_count: int,
    error_message: str = None,
    raw_text: str | None = None,
    cleaned_text: str | None = None,
    chunk_meta: dict | None = None,
):
    """Final callback for succeeded/failed task completion."""
    callback_url, headers = _get_callback_target(task_id)
    if not callback_url or not headers:
        logger.error("APP_BASE_URL or X_INTERNAL_SECRET is not configured. Callback will fail.")
        return

    status = "succeeded" if not error_message else "failed"
    payload = IngestCallback(
        task_code=task_code,
        status=status,
        chunk_count=chunk_count,
        raw_text=raw_text,
        cleaned_text=cleaned_text,
        chunk_meta=chunk_meta,
        error_message=error_message,
    )
    await _post_callback(callback_url, headers, payload, strict=True, label=f"task {task_id}")
